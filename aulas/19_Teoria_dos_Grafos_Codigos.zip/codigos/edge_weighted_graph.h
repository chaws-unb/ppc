#ifndef EDGE_WEIGHTED_GRAPH_H
#define EDGE_WEIGHTED_GRAPH_H

#define MAXV		100
#define MAXDEGREE	100

typedef struct _edge {
	int v;			/* Vértice vizinho */
	int weight;		/* Peso */
} edge;

typedef struct _graph {
	edge edges[MAXV+1][MAXDEGREE];	/* Adjacências */
	int degree[MAV+1];				/* Graus de saída de cada vértice */
	int nvertices;					/* Número de vértices */
	int nedges;						/* Número de arestas */
#endif

