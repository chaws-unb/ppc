#include "bool.h"
#include "backtrack.h"
#include <stdio.h>

void 
process_solution(int a[], int k, data d)
{
	int i;				/* counter */
	
	d->amount++;

/*	printf("%02d: [", d->amount);
	for (i=1; i<=k; i++)
	{
		if (i > 1)
			printf(", ");

		printf("%d", a[i]);
	}

	printf("]\n"); */
}

int
is_a_solution(int a[], int k, data d)
{
	return (k == d->m);
}

void
construct_candidates(int a[], int k, data d, int c[], int *ncandidates)
{
	int i = a[k - 1] + 1;
	int j = 0;

	for (; i <= d->n; i++, j++)
	{
		c[j] = i;
	}

	*ncandidates = j;
}

int 
main(int argc, char *argv[])
{
	int a[NMAX];			/* solution vector */
	sdata dados;

	dados.n = atoi(argv[1]);		
	dados.m = atoi(argv[2]);		
	dados.amount = 0;

	a[0] = 0;

	backtrack(a,0,&dados);

	printf("qtd = %d\n", dados.amount);

}

