#include "bool.h"
#include "backtrack.h"
#include <stdio.h>

void 
process_solution(int a[], int k, int n)
{
	int i;
	
	printf("%d = ", n);
	for (i=1; i<=k; i++)
	{
		if (i > 1)
			printf(", ");

		printf("%d", a[i]);
	}

	printf("\n");
}

int
is_a_solution(int a[], int k, int n)
{
	int i;
	int sum = 0;

	for (i = 1; i <= k; i++)
	{
		sum += a[i];
	}

	if (sum > n)
		finished = TRUE;

	return sum == n;
}

void
construct_candidates(int a[], int k, int n, int c[], int *ncandidates)
{
	int cedulas[] = {2, 5, 10, 20, 50, 100};
	int j = 0;
	int t = a[k - 1];
	int i;

	for (i = 0; i < sizeof(cedulas)/sizeof(int); i++)
		if (cedulas[i] == t)
			break;

	for (; i < 6; i++, j++)
	{
		c[j] = cedulas[i];
	}

	*ncandidates = j;
}

int 
main(int argc, char *argv[])
{
	int a[NMAX];			/* solution vector */
	int n = atoi(argv[1]);		

	a[0] = 2;

	backtrack(a,0,n);
}

