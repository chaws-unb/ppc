#include <stdio.h>

int main()
{
	double a = 0.6;
	float b = 2*0.3;

	if (a == b)
	{
		printf("Operacao ok!\n");
	} else
	{
		printf("0.6 != 2*0.3 ???\n");
	}

	return 0;
}

