#include <stdio.h>

int main()
{
	int a, b, c;
	int i = 0;

	while (scanf("%d %d %d", &a, &b, &c) != EOF)
	{
		printf("Linhas lidas: %d\n", ++i);
	}

	return 0;
}

