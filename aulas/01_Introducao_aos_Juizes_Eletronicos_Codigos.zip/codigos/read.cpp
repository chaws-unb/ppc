#include <iostream>

using namespace std;

int main()
{
	int a, b, c;
	int i = 0;

	while (cin >> a >> b >> c)
	{
		cout << "Linhas lidas: " << ++i << endl;
	}

	return 0;
}

