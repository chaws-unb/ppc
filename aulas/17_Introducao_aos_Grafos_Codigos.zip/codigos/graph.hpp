#ifndef GRAPH_H
#define GRAPH_H

#include <iostream>

using namespace std;

class Graph {
	friend istream& operator>>(istream& is, Graph& graph);
	friend ostream& operator<<(ostream& os, const Graph& graph);

public:
	Graph();

	virtual void insert(int x, int y) = 0;
	
protected:
	enum {MAX_VERTICES = 100, MAX_DEGREE = 50};

	int vertices_count;
	int edges_count;
	int edges[MAX_VERTICES][MAX_DEGREE];
	int degree[MAX_VERTICES];

	void clear();
};

#endif

