#ifndef DIRECTED_H
#define DIRECTED_H

#include "graph.hpp"

class Directed : public Graph {
public:
	void insert(int x, int y);
};

#endif

