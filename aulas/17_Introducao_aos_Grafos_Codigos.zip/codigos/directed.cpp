#include "directed.hpp"

void
Directed::insert(int x, int y)
{
	if (degree[x] == -1)
	{
		degree[x] = 0;
		vertices_count++;
	}

	if (degree[y] == -1)
	{
		degree[y] = 0;
		vertices_count++;
	}

	edges[x][degree[x]] = y;
	degree[x]++;
	edges_count++;
}

