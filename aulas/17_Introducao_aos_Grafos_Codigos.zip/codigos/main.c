#include "graph.h"
#include "bool.h"

int main()
{
	graph directed, g;

	initialize_graph(&directed);
	read_graph(&directed, TRUE);
	printf("Grafo direcinado:\n");
	print_graph(&directed);

	initialize_graph(&g);
	read_graph(&g, FALSE);
	printf("Grafo nao direcinado:\n");
	print_graph(&g);

	return 0;
}

