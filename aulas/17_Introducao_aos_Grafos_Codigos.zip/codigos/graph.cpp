#include "graph.hpp"

istream& 
operator>>(istream& is, Graph& graph)
{
	graph.clear();

	int edges;
	is >> edges;	

	for (int i = 0; i < edges; i++)
	{
		int x, y;
		is >> x >> y;

		graph.insert(x, y);
	}

	return is;		
}

ostream& 
operator<<(ostream& os, const Graph& graph)
{
	os << "Vertices: " << graph.vertices_count << endl;
	os << "Edges: " << graph.edges_count << endl;

	for (int i = 0; i < graph.MAX_VERTICES; i++)
	{
		if (graph.degree[i] != -1)
		{
			os << i << ": ";
		}
	
		for (int j = 0; j < graph.degree[i]; j++)
		{
			os << graph.edges[i][j] << " ";
		}

		if (graph.degree[i] != -1)
		{
			os << endl;
		}
	}

	return os;	
}

void Graph::clear()
{
	vertices_count = 0;
	edges_count = 0;
	
	for (int i = 0; i < MAX_VERTICES; i++)
	{
		degree[i] = -1;
	}
}

Graph::Graph()
{
	clear();
}

