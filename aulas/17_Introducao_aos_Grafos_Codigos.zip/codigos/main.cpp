#include <iostream>
#include "directed.hpp"
#include "undirected.hpp"

using namespace std;

int main()
{
	Undirected undirected;

	cout << "-- Undirected graph" << endl;
	cin >> undirected;
	cout << undirected;

	Directed directed;
	cout << "-- Directed graph" << endl;
	cin >> directed;
	cout << directed;

	return 0;
}

