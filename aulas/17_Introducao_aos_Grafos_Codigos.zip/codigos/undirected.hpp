#ifndef UNDIRECTED_H
#define UNDIRECTED_H

#include "graph.hpp"

class Undirected : public Graph {
public:
	void insert(int x, int y);
};

#endif

