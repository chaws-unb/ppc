#ifndef UNDIRECTED_H
#define UNDIRECTED_H

#include "graph.hpp"

class Undirected : public Graph {
public:
	void insert(int x, int y);
	void process_vertex(int v);
	void process_edge(int x, int y);
	bool valid_edge(int x, int y);
};

#endif

