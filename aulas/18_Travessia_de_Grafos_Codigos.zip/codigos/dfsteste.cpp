#include <iostream>
#include "undirected.hpp"
#include "directed.hpp"

using namespace std;

int main()
{
	Undirected undirected;

	cin >> undirected;
	cout << undirected;

	cout << "DFS: " << endl;
	undirected.dfs(1);

	return 0;
}

