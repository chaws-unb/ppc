#ifndef GRAPH_H
#define GRAPH_H

#include <iostream>
#include <vector>
#include <stack>

using namespace std;

class Graph {
	friend istream& operator>>(istream& is, Graph& graph);
	friend ostream& operator<<(ostream& os, const Graph& graph);

public:
	Graph();

	virtual void insert(int x, int y) = 0;
	
	virtual void process_vertex(int v) = 0;
	virtual void process_edge(int x, int y, int parent[]) = 0;
	virtual bool valid_edge(int x, int y) = 0;

	vector<int> bfs(int start);
	vector<int> dfs(int root);

	stack<int> shortest_path(int vertex, int root, const vector<int>& parents);
	int connected_components();

protected:
	enum {MAX_VERTICES = 100, MAX_DEGREE = 50};
	typedef enum {UNVISITED, DISCOVERED, PROCESSED} VertexStatus;

	int vertices_count;
	int edges_count;
	int edges[MAX_VERTICES][MAX_DEGREE];
	int degree[MAX_VERTICES];

	void clear();
	void rdfs(int vertex, VertexStatus status[], int parent[]);
};

#endif

