#include <queue>
#include "graph2.hpp"

istream& 
operator>>(istream& is, Graph& graph)
{
	graph.clear();

	int edges;
	is >> edges;	

	for (int i = 0; i < edges; i++)
	{
		int x, y;
		is >> x >> y;

		graph.insert(x, y);
	}

	return is;		
}

ostream& 
operator<<(ostream& os, const Graph& graph)
{
	os << "Vertices: " << graph.vertices_count << endl;
	os << "Edges: " << graph.edges_count << endl;

	for (int i = 0; i < graph.MAX_VERTICES; i++)
	{
		if (graph.degree[i] != -1)
		{
			os << i << ": ";
		}
	
		for (int j = 0; j < graph.degree[i]; j++)
		{
			os << graph.edges[i][j] << " ";
		}

		if (graph.degree[i] != -1)
		{
			os << endl;
		}
	}

	return os;	
}

void Graph::clear()
{
	vertices_count = 0;
	edges_count = 0;
	
	for (int i = 0; i < MAX_VERTICES; i++)
	{
		degree[i] = -1;
	}
}

Graph::Graph()
{
	clear();
}

vector<int> 
Graph::bfs(int start) 
{
	VertexStatus status[MAX_VERTICES];
	int parent[MAX_VERTICES];

	for (int i = 0; i < MAX_VERTICES; i++)
	{
		status[i] = UNVISITED;
		parent[i] = -1;
	}

	queue<int> q;

	q.push(start);
	status[start] = DISCOVERED;

	while (q.empty() == false)
	{
		int vertex = q.front();
		q.pop();

		process_vertex(vertex);
		status[vertex] = PROCESSED;

		for (int i = 0; i < degree[vertex]; i++)
		{
			int adjacent = edges[vertex][i];

			if (valid_edge(vertex, adjacent) == false)
			{
				continue;
			}

			if (status[adjacent] == UNVISITED)
			{
				q.push(adjacent);
				status[adjacent] = DISCOVERED;
				parent[adjacent] = vertex;
			}

			process_edge(vertex, adjacent, parent);
		}
	}

	cout << "Parents:" << endl;

	for (int i = 0; i < MAX_VERTICES; i++)
	{
		if (degree[i] > -1)
		{
			cout << i << ": " << parent[i] << endl;
		}
	}

	return vector<int>(parent, parent + vertices_count + 1);
}

vector<int> 
Graph::dfs(int root)
{
	VertexStatus status[MAX_VERTICES];
	int parent[MAX_VERTICES];

	for (int i = 0; i < MAX_VERTICES; i++)
	{
		status[i] = UNVISITED;
		parent[i] = -1;
	}

	rdfs(root, status, parent);

	return vector<int>(parent, parent + vertices_count + 1);
}

void 
Graph::rdfs(int vertex, VertexStatus status[], int parent[])
{
	status[vertex] = DISCOVERED;
	process_vertex(vertex);

	for (int i = 0; i < degree[vertex]; i++)
	{
		int adjacent = edges[vertex][i];

		if (valid_edge(vertex, adjacent) == false)
		{
			continue;
		}

		if (status[adjacent] == UNVISITED)
		{
			parent[adjacent] = vertex;
			rdfs(adjacent, status, parent);
		} else
		{
			if (status[adjacent] != PROCESSED)
			{
				process_edge(vertex, adjacent, parent);
			}
		}
	}

	status[vertex] = PROCESSED;	
}

stack<int> 
Graph::shortest_path(int vertex, int root, const vector<int>& parents)
{
	stack<int> path;

	int next = vertex;
	path.push(next);

	while (parents[next] != root)
	{
		next = parents[next];
		path.push(next);
	}

	return path;
}

int 
Graph::connected_components()
{
	VertexStatus status[MAX_VERTICES];
	int parent[MAX_VERTICES];

	for (int i = 0; i < MAX_VERTICES; i++)
	{
		status[i] = UNVISITED;
		parent[i] = -1;
	}

	int components = 0;
	
	for (int i = 1; i <= vertices_count; i++)
	{
		if (status[i] == UNVISITED)
		{
			components++;
			cout << "Component: " << components << endl;

			rdfs(i, status, parent);
		}
	}

	return components;
}

