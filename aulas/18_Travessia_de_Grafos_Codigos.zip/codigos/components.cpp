#include <iostream>
#include "undirected2.hpp"
#include "directed2.hpp"

using namespace std;

int main()
{
	Undirected undirected;

	cin >> undirected;
	cout << undirected;

	cout << "Componentes conectados: " << undirected.connected_components()
		<< endl;

	return 0;
}

