#include <iostream>
#include "undirected.hpp"
#include "directed.hpp"

using namespace std;

int main()
{
	Directed undirected;

	cin >> undirected;
	cout << undirected;

	cout << "BSF: " << endl;
	undirected.bfs(1);

	return 0;
}

