/*	bool.h
	Simple boolean datatype
*/

#define TRUE    1
#define FALSE   0

typedef int bool;

