#include <iostream>
#include "undirected.hpp"
#include "directed.hpp"

using namespace std;

int main()
{
	Undirected undirected;

	cin >> undirected;
	cout << undirected;

	cout << "BSF: " << endl;
	vector<int> parents = undirected.bfs(1);

	cout << "Escolha o elemento cujo caminho sera determinado: ";

	int vertex;
	cin >> vertex;

	stack<int> path = undirected.shortest_path(vertex, parents);

	cout << "Caminho para " << vertex << ": ";

	while (path.empty() == false)
	{
		cout << path.top() << " ";
		path.pop();
	}

	cout << endl;

	return 0;
}

