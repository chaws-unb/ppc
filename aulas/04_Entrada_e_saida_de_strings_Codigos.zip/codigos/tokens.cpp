#include <iostream>
#include <string>

using namespace std;

int main()
{
	string text;
	int day, month, year;
	char c;

	while (!cin.eof())
	{
		cin >> text >> day >> c >> month >> c >> year >> c;

		cout << "Dia: " << day << ", mes: " << month << ", ano: " << year 
			<< endl;
	}

	return 0;
}

