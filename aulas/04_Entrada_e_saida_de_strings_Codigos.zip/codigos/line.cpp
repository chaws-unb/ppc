#include <iostream>

using namespace std;

const int MaxBufferSize = 4096;

int main()
{
	char line[MaxBufferSize];

	while (cin.getline(line, MaxBufferSize))
	{
		cout << "Linha lida: [" << line << "]\n";
	}

	return 0;
}

