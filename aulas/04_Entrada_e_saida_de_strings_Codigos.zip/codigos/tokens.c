#include <stdio.h>

#define MAX_TEXT_SIZE 16

int main()
{
	char text[MAX_TEXT_SIZE];
	int day, month, year;

	while (!feof(stdin))
	{
		scanf("%s %d/%d/%d\n", text, &day, &month, &year);

		printf("Dia: %d, mes: %d, ano: %d\n", day, month, year);
	}

	return 0;
}

