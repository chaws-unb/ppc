#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

int main()
{
	int c;
	char buffer[5];
	int index;
	int month, day, year;

	while (1)
	{	
		/* Descarta o texto inicial, antes da data */
		do {
			c = getchar();

			if (c == EOF)
			{
				return 0;
			}

		} while (!isdigit(c));
	
		ungetc(c, stdin);

		/* Le o dia e despreza a barra subsequente */
		for (index = 0; index < 2; index++)
		{
			buffer[index] = getchar();
		}
	
		buffer[index] = 0;
		c = getchar();
	
		day = atoi(buffer);
	
		/* Repete o processo para o mes */
		for (index = 0; index < 2; index++)
		{
			buffer[index] = getchar();
		}
	
		buffer[index] = 0;
		c = getchar();
	
		month = atoi(buffer);
	
		/* Repete o processo para o ano */
		for (index = 0; index < 4; index++)
		{
			buffer[index] = getchar();
		}
	
		buffer[index] = 0;
		c = getchar();
	
		year = atoi(buffer);
	
		printf("Dia: %d, mes: %d, ano: %d\n", day, month, year);
	}

	return 0;
}
	
