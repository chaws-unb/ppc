#include <stdio.h>

#define MAX_BUFFER_SIZE 4096

int main()
{
	char line[MAX_BUFFER_SIZE];

	while (1)
	{
		fgets(line, MAX_BUFFER_SIZE, stdin);

		if (feof(stdin))
		{
			break;
		}

		printf("Linha lida: [%s]\n", line);
	}

	return 0;
}

