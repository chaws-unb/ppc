#include <iostream>
#include <cstdlib>
#include <cctype>

using namespace std;

int main()
{
	char c;
	char buffer[5];
	int index;
	int month, day, year;

	while (1)
	{	
		/* Descarta o texto inicial, antes da data */
		do {
			cin >> c;

			if (cin.eof())
			{
				return 0;
			}

		} while (!isdigit(c));
	
		cin.unget();

		/* Le o dia e despreza a barra subsequente */
		for (index = 0; index < 2; index++)
		{
			cin >> buffer[index];
		}
	
		buffer[index] = 0;
		cin.ignore(1, '/');
	
		day = atoi(buffer);
	
		/* Repete o processo para o mes */
		for (index = 0; index < 2; index++)
		{
			cin >> buffer[index];
		}
	
		buffer[index] = 0;
		cin.ignore(1, '/');
	
		month = atoi(buffer);
	
		/* Repete o processo para o ano */
		for (index = 0; index < 4; index++)
		{
			cin >> buffer[index];
		}
	
		buffer[index] = 0;
		cin.ignore(1, '\n');
	
		year = atoi(buffer);
	
		cout << "Dia: " << day << ", mes: " << month << ", ano: " << year 
			<< endl;
	}

	return 0;
}
	
